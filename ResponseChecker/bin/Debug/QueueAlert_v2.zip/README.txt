HOW TO

* Start program
* Click start
* Select area where the timer is
* Then wait 5 sec for it to activate

That should be it, now it will play the sound if it sees a number lower than 100
(It checks every 5 sec, and it needs to see it atleast 5 times before it activates)
(So if u instantly get in then it wont do anything)